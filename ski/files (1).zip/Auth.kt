package com.example.snowshop

import android.content.Context
import android.util.Patterns
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest
import java.util.UUID

// ---------- ALMACÉN DE USUARIOS (local, en el dispositivo) ----------
class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("snowshop_auth", Context.MODE_PRIVATE)

    // Nombre del usuario con sesión iniciada (null = no hay sesión)
    var currentUser by mutableStateOf<String?>(null)
        private set

    init {
        currentUser = prefs.getString("session_email", null)?.let { parse(it)?.first }
    }

    private fun hash(password: String, salt: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest((salt + password).toByteArray())
            .joinToString("") { "%02x".format(it) }

    // Guardado como "nombre|salt|hash" -> devuelve (nombre, salt, hash)
    private fun parse(email: String): Triple<String, String, String>? {
        val parts = prefs.getString("user_$email", null)?.split("|") ?: return null
        if (parts.size < 3) return null
        return Triple(parts.dropLast(2).joinToString("|"), parts[parts.size - 2], parts.last())
    }

    /** Devuelve null si todo OK, o el mensaje de error. */
    fun register(name: String, email: String, password: String, confirm: String): String? {
        val key = email.trim().lowercase()
        if (name.isBlank()) return "Introduce tu nombre"
        if (!Patterns.EMAIL_ADDRESS.matcher(key).matches()) return "El email no es válido"
        if (password.length < 6) return "La contraseña debe tener al menos 6 caracteres"
        if (password != confirm) return "Las contraseñas no coinciden"
        if (prefs.contains("user_$key")) return "Ya existe una cuenta con ese email"

        val salt = UUID.randomUUID().toString()
        prefs.edit()
            .putString("user_$key", "${name.trim()}|$salt|${hash(password, salt)}")
            .putString("session_email", key)
            .apply()
        currentUser = name.trim()
        return null
    }

    /** Devuelve null si todo OK, o el mensaje de error. */
    fun login(email: String, password: String): String? {
        val key = email.trim().lowercase()
        if (key.isBlank() || password.isBlank()) return "Rellena todos los campos"
        val (name, salt, storedHash) = parse(key) ?: return "Email o contraseña incorrectos"
        if (hash(password, salt) != storedHash) return "Email o contraseña incorrectos"

        prefs.edit().putString("session_email", key).apply()
        currentUser = name
        return null
    }

    fun logout() {
        prefs.edit().remove("session_email").apply()
        currentUser = null
    }
}

// ---------- CAMPOS REUTILIZABLES ----------
@Composable
private fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        visualTransformation = if (password && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = if (password) {
            { TextButton(onClick = { visible = !visible }) { Text(if (visible) "Ocultar" else "Mostrar", fontSize = 12.sp) } }
        } else null,
        modifier = Modifier.fillMaxWidth()
    )
}

// ---------- LOGIN ----------
@Composable
fun LoginScreen(auth: AuthStore, onGoRegister: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("❄️", fontSize = 64.sp)
        Text("SnowShop", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Inicia sesión para continuar", color = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(24.dp))

        AuthField(email, { email = it; error = null }, "Email", KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        AuthField(password, { password = it; error = null }, "Contraseña", password = true)

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { error = auth.login(email, password) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Iniciar sesión") }

        TextButton(onClick = onGoRegister) { Text("¿No tienes cuenta? Regístrate") }
    }
}

// ---------- REGISTRO ----------
@Composable
fun RegisterScreen(auth: AuthStore, onGoLogin: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Crear cuenta", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        AuthField(name, { name = it; error = null }, "Nombre")
        Spacer(Modifier.height(12.dp))
        AuthField(email, { email = it; error = null }, "Email", KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        AuthField(password, { password = it; error = null }, "Contraseña", password = true)
        Spacer(Modifier.height(12.dp))
        AuthField(confirm, { confirm = it; error = null }, "Repite la contraseña", password = true)

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { error = auth.register(name, email, password, confirm) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Registrarme") }

        TextButton(onClick = onGoLogin) { Text("¿Ya tienes cuenta? Inicia sesión") }
    }
}
